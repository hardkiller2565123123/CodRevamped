#include "HttpRouter.h"

namespace revamped::iw8::web
{
    HttpResult TryHandleLocalWebRequest(std::vector<std::uint8_t>& buffer)
    {
        HttpResult result{};
        if (buffer.empty()) return result;

        const std::string all(reinterpret_cast<const char*>(buffer.data()), buffer.size());
        const std::size_t headerEndMarker = all.find("\r\n\r\n");
        if (headerEndMarker == std::string::npos)
            return result;

        const std::size_t headerBytes = headerEndMarker + 4;
        const std::string headers = all.substr(0, headerEndMarker + 2);
        const std::string contentLengthText = HeaderValue(headers, "Content-Length");
        std::size_t contentLength = 0;
        if (!contentLengthText.empty())
        {
            char* end = nullptr;
            const unsigned long long parsed = std::strtoull(contentLengthText.c_str(), &end, 10);
            if (!end || end == contentLengthText.c_str() || *end != '\0' || parsed > 1024ull * 1024ull)
            {
                result.complete = true;
                result.handled = false;
                result.statusCode = 400;
                result.label = "invalid Content-Length";
                result.response = BuildResponse(400, "Bad Request", "application/json", "{\"error\":\"bad_request\"}");
                buffer.clear();
                return result;
            }
            contentLength = static_cast<std::size_t>(parsed);
        }

        const std::size_t totalBytes = headerBytes + contentLength;
        if (buffer.size() < totalBytes)
            return result;

        result.complete = true;
        result.requestBytes = totalBytes;

        const std::size_t firstLineEnd = headers.find("\r\n");
        if (firstLineEnd == std::string::npos)
        {
            result.statusCode = 400;
            result.label = "malformed request line";
            result.response = BuildResponse(400, "Bad Request", "application/json", "{\"error\":\"bad_request\"}");
            buffer.erase(buffer.begin(), buffer.begin() + static_cast<std::ptrdiff_t>(totalBytes));
            return result;
        }

        const std::string requestLine = headers.substr(0, firstLineEnd);
        const std::size_t firstSpace = requestLine.find(' ');
        const std::size_t secondSpace = firstSpace == std::string::npos ? std::string::npos : requestLine.find(' ', firstSpace + 1);
        if (firstSpace == std::string::npos || secondSpace == std::string::npos)
        {
            result.statusCode = 400;
            result.label = "malformed request line";
            result.response = BuildResponse(400, "Bad Request", "application/json", "{\"error\":\"bad_request\"}");
            buffer.erase(buffer.begin(), buffer.begin() + static_cast<std::ptrdiff_t>(totalBytes));
            return result;
        }

        result.method = requestLine.substr(0, firstSpace);
        std::string target = requestLine.substr(firstSpace + 1, secondSpace - firstSpace - 1);
        result.host = HeaderValue(headers, "Host");
        // Be tolerant of absolute-form HTTP request targets as well as normal
        // origin-form paths; redirected clients can use either.
        const std::string targetLower = Lower(target);
        if (targetLower.rfind("https://", 0) == 0 || targetLower.rfind("http://", 0) == 0)
        {
            const std::size_t authorityStart = target.find("//") + 2;
            const std::size_t pathStart = target.find('/', authorityStart);
            if (result.host.empty())
                result.host = target.substr(authorityStart, pathStart == std::string::npos ? std::string::npos : pathStart - authorityStart);
            target = pathStart == std::string::npos ? "/" : target.substr(pathStart);
        }
        const std::size_t question = target.find('?');
        result.path = target.substr(0, question);
        const std::string hostLower = Lower(result.host);
        const std::string pathLower = Lower(result.path);
        const std::string query = question == std::string::npos ? std::string{} : target.substr(question + 1);
        const std::string body = contentLength ? all.substr(headerBytes, contentLength) : std::string{};
        const bool umbrellaLegacyLsgPath = pathLower == "/v1.0/tokens/lsg/";
        const bool umbrellaCrossplayPath = pathLower == "/v1.0/tokens/crossplatform/";
        const char* umbrellaSuffix = ".umbrella.demonware.net";
        const std::size_t umbrellaSuffixLength = std::strlen(umbrellaSuffix);
        const bool umbrellaHost = hostLower == "umbrella.demonware.net" ||
            (hostLower.size() > umbrellaSuffixLength &&
             hostLower.compare(hostLower.size() - umbrellaSuffixLength, umbrellaSuffixLength, umbrellaSuffix) == 0);

        const std::string contentTypeLower = Lower(HeaderValue(headers, "Content-Type"));
        const bool bodyIsJson = contentTypeLower.find("application/json") != std::string::npos || LooksLikeJsonObject(body);
        const bool bodyIsForm = !bodyIsJson &&
            (contentTypeLower.find("application/x-www-form-urlencoded") != std::string::npos || body.find('=') != std::string::npos);
        const std::string queryKeys = FieldKeys(query);
        const std::string bodyKeys = bodyIsJson ? JsonTopLevelKeys(body) : (bodyIsForm ? FieldKeys(body) : std::string{});
        if (!queryKeys.empty() && !bodyKeys.empty()) result.formKeys = queryKeys + "," + bodyKeys;
        else result.formKeys = !queryKeys.empty() ? queryKeys : bodyKeys;

        // MW2019 obtains a short-lived OAuth access token immediately after
        // AuthenticationService.GenerateWebCredentials.  Accept only the local
        // synthetic client_sso shape; no Blizzard username/password is accepted.
        const bool oauthHost = hostLower.find("oauth-") == 0 || hostLower.find("battle.net") != std::string::npos;
        const bool oauthPath = pathLower == "/oauth" || pathLower.find("/oauth/") == 0;
        const bool clientSso = HasFormPair(query, "grant_type", "client_sso") ||
            HasFormPair(body, "grant_type", "client_sso");
        if ((oauthPath || oauthHost) && clientSso)
        {
            const std::string responseBody =
                "{\"access_token\":\"revamped-iw8-local-access-token\","
                "\"token_type\":\"bearer\",\"expires_in\":86400,"
                "\"scope\":\"account.standard\"}";
            result.handled = true;
            result.statusCode = 200;
            result.label = "local OAuth client_sso access token";
            result.response = BuildResponse(200, "OK", "application/json; charset=utf-8", responseBody);
        }
        else if (result.method == "POST" &&
            umbrellaHost &&
            (umbrellaLegacyLsgPath || umbrellaCrossplayPath))
        {
            // Stock IW8 reaches this exchange only after the signed Auth3 response
            // has been accepted far enough to request an LSG token.  Keep this
            // server-driven: validate the captured request shape and issue a local
            // deterministic token; no client login/fence state is modified.
            // IW8 1.44 sends these values on the URL query for this POST.  The
            // generic request logger intentionally reports query + body keys as
            // one formKeys list, so validate both sources here as well.  Other
            // builds may choose a normal urlencoded body, so keep that accepted.
            const bool queryHasClient = HasFormKey(query, "client");
            const bool queryHasTicket = HasFormKey(query, "ticket");
            const bool queryHasIvSeed = HasFormKey(query, "initialVectorSeed");
            const bool queryHasTitleId = HasFormKey(query, "titleID");
            const bool queryHasAuthToken = HasFormKey(query, "authToken");
            const bool formHasClient = bodyIsForm && HasFormKey(body, "client");
            const bool formHasTicket = bodyIsForm && HasFormKey(body, "ticket");
            const bool formHasIvSeed = bodyIsForm && HasFormKey(body, "initialVectorSeed");
            const bool formHasTitleId = bodyIsForm && HasFormKey(body, "titleID");
            const bool formHasAuthToken = bodyIsForm && HasFormKey(body, "authToken");

            // IW8 1.44 actually splits this POST across sources: `client` is
            // carried by the URL query while the ticket/IV/title fields are a
            // JSON object in the request body.  The generic formKeys logger has
            // always merged query keys with JSON top-level keys, which is why it
            // could see all four while the v15 endpoint validator only saw
            // `client`.  Use the same accepted sources here so diagnostics and
            // endpoint validation cannot disagree again.
            const bool jsonHasClient = bodyIsJson && JsonValueType(body, "client") != '-';
            const bool jsonHasTicket = bodyIsJson && JsonValueType(body, "ticket") != '-';
            const bool jsonHasIvSeed = bodyIsJson && JsonValueType(body, "initialVectorSeed") != '-';
            const bool jsonHasTitleId = bodyIsJson && JsonValueType(body, "titleID") != '-';
            const bool jsonHasAuthToken = bodyIsJson && JsonValueType(body, "authToken") != '-';

            const bool hasClient = queryHasClient || formHasClient || jsonHasClient;
            const bool hasTicket = queryHasTicket || formHasTicket || jsonHasTicket;
            const bool hasIvSeed = queryHasIvSeed || formHasIvSeed || jsonHasIvSeed;
            const bool hasTitleId = queryHasTitleId || formHasTitleId || jsonHasTitleId;
            const bool hasAuthToken = queryHasAuthToken || formHasAuthToken || jsonHasAuthToken;
            const bool requiresAuthToken = umbrellaCrossplayPath;

            const char* bodyStyle = bodyIsJson ? "json" : (bodyIsForm ? "form" : "none");
            const char* fieldSource = !query.empty() && bodyIsJson ? "query+json" :
                (!query.empty() && bodyIsForm ? "query+form" :
                (!query.empty() ? "query" : (bodyIsJson ? "json" : (bodyIsForm ? "form" : "none"))));
            const char* umbrellaRoute = umbrellaCrossplayPath ? "crossplatform" : "lsg";
            std::ostringstream detail;
            detail << "local Demonware Umbrella " << umbrellaRoute << " token exchange"
                   << " fieldSource=" << fieldSource
                   << " bodyStyle=" << bodyStyle
                   << " client=" << (hasClient ? "present" : "missing")
                   << " ticket=" << (hasTicket ? "present" : "missing")
                   << " initialVectorSeed=" << (hasIvSeed ? "present" : "missing")
                   << " titleID=" << (hasTitleId ? "present" : "missing")
                   << " authToken=" << (hasAuthToken ? "present" : "missing")
                   << " values=REDACTED responseStyle=UMBRELLA_NATIVE_LSG_HANDOFF stateWrites=off";

            result.handled = true;
            if (!hasClient || !hasTicket || !hasIvSeed || !hasTitleId || (requiresAuthToken && !hasAuthToken))
            {
                result.statusCode = 400;
                result.label = detail.str();
                AppendAuthPipelineV58("UMBRELLA_REJECT route=%s shape client=%s ticket=%s iv=%s title=%s authToken=%s source=%s",
                    umbrellaRoute,
                    hasClient ? "present" : "missing", hasTicket ? "present" : "missing",
                    hasIvSeed ? "present" : "missing", hasTitleId ? "present" : "missing",
                    hasAuthToken ? "present" : "missing", fieldSource);
                result.response = BuildResponse(400, "Bad Request",
                    "application/json; charset=utf-8",
                    umbrellaCrossplayPath
                        ? "{\"error\":\"revamped_bad_umbrella_crossplatform_shape\"}"
                        : "{\"error\":\"revamped_bad_umbrella_lsg_shape\"}");
            }
            else
            {
                // The stock 1.44 request carries its Umbrella `ticket` as a JSON
                // string. Returning a made-up printable token proved insufficient.
                // The stock request itself is useful here as the Auth3 credential
                // presented to Umbrella; V67 mints a separate structured LSG token
                // below instead of echoing this request credential back to the client.
                std::string requestTicket;
                const char ticketValueType = bodyIsJson ? JsonValueType(body, "ticket") : '-';
                bool requestTicketExtracted = false;
                if (bodyIsJson && ticketValueType == 's')
                    requestTicketExtracted = JsonStringValue(body, "ticket", requestTicket);
                else if (bodyIsJson && ticketValueType != '-')
                    requestTicketExtracted = JsonUnsignedText(body, "ticket", requestTicket);

                // V72: IW8 1.44 carries initialVectorSeed in the JSON body on the
                // proven path.  Preserve its exact textual representation without
                // logging it so the LSG oracle can test raw/base64/hex 24-byte
                // interpretations alongside the ticket-carried session keys.
                std::string umbrellaInitialVectorSeed;
                if (bodyIsJson)
                {
                    const char ivType = JsonValueType(body, "initialVectorSeed");
                    if (ivType == 's')
                        JsonStringValue(body, "initialVectorSeed", umbrellaInitialVectorSeed);
                    else if (ivType != '-')
                        JsonUnsignedText(body, "initialVectorSeed", umbrellaInitialVectorSeed);
                }
                g_authPipeline.lastUmbrellaInitialVectorSeed = umbrellaInitialVectorSeed;

                const Auth3TicketMatch ticketMatch = CorrelateUmbrellaTicket(requestTicket);

                // V67: the request's Auth3 server_ticket is the credential used
                // to authorize this exchange, but it is not the credential we
                // return to bdLobby.  V61 proved the host-only endpoint reaches
                // native LSG; V66 then proved the echoed server_ticket has no DW
                // ticket magic/session key at the packed ticket offsets.  Mint a
                // structured LSG ticket tied to the same Auth3 session key.
                const bool requestServerTicketVerified =
                    requestTicketExtracted &&
                    !requestTicket.empty() &&
                    ticketMatch.exactServerMatch;

                // 1.20's native crossplatform request explicitly carries titleID.
                // Prefer that request value when it is a sane uint32, then fall
                // back to the correlated Auth3 ticket and finally IW8's known
                // title id. This keeps the handler semantic across build layouts.
                std::uint32_t requestTitleId = 0u;
                std::string requestTitleText;
                if (bodyIsJson)
                {
                    const char titleType = JsonValueType(body, "titleID");
                    if (titleType == 's')
                        JsonStringValue(body, "titleID", requestTitleText);
                    else if (titleType != '-')
                        JsonUnsignedText(body, "titleID", requestTitleText);
                }
                if (!requestTitleText.empty())
                {
                    char* end = nullptr;
                    const unsigned long parsed = std::strtoul(requestTitleText.c_str(), &end, 10);
                    if (end && *end == '\0' && parsed <= 0xFFFFFFFFul)
                        requestTitleId = static_cast<std::uint32_t>(parsed);
                }

                const std::uint32_t lsgTitleId = requestTitleId != 0u
                    ? requestTitleId
                    : (ticketMatch.titleId != 0u ? ticketMatch.titleId : 5800u);
                std::string localLsgToken = BuildLocalLsgTokenV67(lsgTitleId);
                if (localLsgToken.empty() && ticketMatch.haveAuth3ClientTicket)
                    localLsgToken = g_authPipeline.lastAuth3ClientTicket;
                g_authPipeline.lastMintedLsgToken = localLsgToken;

                const UmbrellaTicketShape ticketShape = DescribeUmbrellaTicket(requestTicket);
                const UmbrellaTicketShape responseTicketShape = DescribeUmbrellaTicket(localLsgToken);
                const std::string requestTicketHash = Sha256Prefix(requestTicket);
                const std::string auth3ClientHash = Sha256Prefix(g_authPipeline.lastAuth3ClientTicket);
                const std::string auth3ServerHash = Sha256Prefix(g_authPipeline.lastAuth3ServerTicket);
                AppendAuthPipelineV58("UMBRELLA_REQUEST auth3Serial=%llu ageMs=%llu ticketType=%c ticketLen=%llu requestHash=%s auth3ClientHash=%s auth3ServerHash=%s exactClient=%s exactServer=%s decodedBytes=%llu dwAuthMagic=%s titleId=%u values=REDACTED",
                    static_cast<unsigned long long>(ticketMatch.serial), static_cast<unsigned long long>(ticketMatch.ageMs),
                    ticketValueType, static_cast<unsigned long long>(requestTicket.size()), requestTicketHash.c_str(),
                    auth3ClientHash.c_str(), auth3ServerHash.c_str(), ticketMatch.exactClientMatch ? "YES" : "NO",
                    ticketMatch.exactServerMatch ? "YES" : "NO", static_cast<unsigned long long>(ticketShape.decodedBytes),
                    ticketShape.dwAuthTicketMagic ? "YES" : "NO", static_cast<unsigned>(ticketShape.titleId));

                detail << " ticketType=" << ticketValueType
                       << " ticketLen=" << requestTicket.size()
                       << " tokenSource="
                       << (!localLsgToken.empty() ? "mintedDwAuthTicketV67" : "fallback")
                       << " auth3Serial=" << ticketMatch.serial
                       << " auth3AgeMs=" << static_cast<unsigned long long>(ticketMatch.ageMs)
                       << " ticketMatchesAuth3Client=" << (ticketMatch.exactClientMatch ? "YES" : "NO")
                       << " ticketMatchesAuth3Server=" << (ticketMatch.exactServerMatch ? "YES" : "NO")
                       << " auth3ClientPresent=" << (ticketMatch.haveAuth3ClientTicket ? "yes" : "no")
                       << " auth3ServerPresent=" << (ticketMatch.haveAuth3ServerTicket ? "yes" : "no")
                       << " responseStyle=UMBRELLA_STOCK_NAMED_V15";

                log::Print("[LSG-TICKET-CORRELATION] auth3Serial=%llu requestHash=%s auth3ClientHash=%s auth3ServerHash=%s exactClient=%s exactServer=%s base64=%s decodedBytes=%llu dwAuthMagic=%s type=%u titleId=%u issued=%u expires=%u sessionKeyNonZero=%u values=REDACTED stateWrites=off",
                    static_cast<unsigned long long>(ticketMatch.serial),
                    requestTicketHash.c_str(), auth3ClientHash.c_str(), auth3ServerHash.c_str(),
                    ticketMatch.exactClientMatch ? "YES" : "NO",
                    ticketMatch.exactServerMatch ? "YES" : "NO",
                    ticketShape.base64Ok ? "yes" : "no",
                    static_cast<unsigned long long>(ticketShape.decodedBytes),
                    ticketShape.dwAuthTicketMagic ? "YES" : "NO",
                    static_cast<unsigned>(ticketShape.type),
                    static_cast<unsigned>(ticketShape.titleId),
                    static_cast<unsigned>(ticketShape.timeIssued),
                    static_cast<unsigned>(ticketShape.timeExpires),
                    ticketShape.sessionKeyNonZero);

                log::Print("[AUTH-V67] LSG_TOKEN_MINTED auth3Serial=%llu requestServerTicketVerified=%s rawBytes=%llu dwAuthMagic=%s type=%u titleId=%u issued=%u expires=%u sessionKeyNonZero=%u tokenHash=%s values=REDACTED stateWrites=off",
                    static_cast<unsigned long long>(ticketMatch.serial),
                    requestServerTicketVerified ? "YES" : "NO",
                    static_cast<unsigned long long>(responseTicketShape.decodedBytes),
                    responseTicketShape.dwAuthTicketMagic ? "YES" : "NO",
                    static_cast<unsigned>(responseTicketShape.type),
                    static_cast<unsigned>(responseTicketShape.titleId),
                    static_cast<unsigned>(responseTicketShape.timeIssued),
                    static_cast<unsigned>(responseTicketShape.timeExpires),
                    responseTicketShape.sessionKeyNonZero,
                    Sha256Prefix(localLsgToken).c_str());
                AppendAuthPipelineV58("AUTH_V67_LSG_TOKEN_MINTED auth3Serial=%llu requestServerTicketVerified=%s rawBytes=%llu dwAuthMagic=%s titleId=%u sessionKeyNonZero=%u tokenHash=%s next=expect_native_0x82",
                    static_cast<unsigned long long>(ticketMatch.serial),
                    requestServerTicketVerified ? "YES" : "NO",
                    static_cast<unsigned long long>(responseTicketShape.decodedBytes),
                    responseTicketShape.dwAuthTicketMagic ? "YES" : "NO",
                    static_cast<unsigned>(responseTicketShape.titleId),
                    responseTicketShape.sessionKeyNonZero,
                    Sha256Prefix(localLsgToken).c_str());

                // Native 1.20 maps `lsgEndpoint` directly to the hostname buffer
                // and hardcodes TCP 3074 in the LSG task constructor.  Keep the
                // endpoint host-only.  The response also carries the account-token
                // fields parsed by the stock Umbrella account object plus the
                // crossPlatformProgressionEnabled flag observed in the native parser.
                // No client login/fence state is forced here.
                const LONG responseOrdinal = InterlockedIncrement(&g_authPipeline.umbrellaSweepCount);
                const std::string responseToken = localLsgToken;
                const std::string localLobbyEndpoint = "127.0.0.1";
                const std::string responseBody =
                    "{\"umbrellaID\":1,\"accessToken\":\"" + JsonEscape(responseToken) +
                    "\",\"expires\":86400,\"accounts\":[],"
                    "\"token\":\"" + JsonEscape(responseToken) +
                    "\",\"crossPlatformProgressionEnabled\":true,"
                    "\"lsgEndpoint\":\"" + JsonEscape(localLobbyEndpoint) + "\"}";
                result.statusCode = 200;
                result.label = detail.str();
                result.response = BuildResponse(200, "OK", "application/json; charset=utf-8", responseBody);
                MarkUmbrellaLsgAccepted(ticketMatch.serial);

                log::Print("[AUTH-LSG] UMBRELLA_RESPONSE route=%s ordinal=%ld auth3Serial=%llu exactServer=%s schema=NATIVE_CROSSPLAY_LSG tokenSource=%s tokenLen=%llu endpoint=%s endpointFormat=HOST_ONLY clientPortPolicy=FIXED_3074 crossPlatformProgressionEnabled=true deterministic=yes next=expect_TCP_3074",
                    umbrellaRoute,
                    static_cast<long>(responseOrdinal), static_cast<unsigned long long>(ticketMatch.serial),
                    ticketMatch.exactServerMatch ? "YES" : "NO",
                    "mintedDwAuthTicketV67",
                    static_cast<unsigned long long>(responseToken.size()), localLobbyEndpoint.c_str());
                AppendAuthPipelineV58("AUTH_LSG_UMBRELLA_RESPONSE route=%s ordinal=%ld auth3Serial=%llu exactServer=%s schema=NATIVE_CROSSPLAY_LSG tokenSource=%s tokenLen=%llu endpoint=%s endpointFormat=HOST_ONLY clientPortPolicy=FIXED_3074 crossPlatformProgressionEnabled=true deterministic=yes next=expect_TCP_3074",
                    umbrellaRoute,
                    static_cast<long>(responseOrdinal), static_cast<unsigned long long>(ticketMatch.serial),
                    ticketMatch.exactServerMatch ? "YES" : "NO",
                    "mintedDwAuthTicketV67",
                    static_cast<unsigned long long>(responseToken.size()), localLobbyEndpoint.c_str());
            }
        }
        else if (result.method == "POST" && pathLower == "/v1/login/" &&
            hostLower.find("-steam-loginservice.prod.demonware.net") != std::string::npos)
        {
            // Current Steam Retail no longer starts with the older /auth/ Auth3
            // transaction.  It first exchanges the Steam platform token at
            // <game>-steam-loginservice.prod.demonware.net/v1/login/.  Returning
            // 404 here makes stock IW8 close the TLS connection and retry forever,
            // which looks like a frontend freeze after accepting the EULA.
            //
            // Keep this local/offline: consume only the request shape, never send
            // the supplied Steam token anywhere, and mint the same deterministic
            // local DW ticket/session material used by the existing Auth3 path.
            const auto readField = [&](const char* name, std::string& value) -> bool
            {
                if (FormValue(query, name, value)) return true;
                if (bodyIsForm && FormValue(body, name, value)) return true;
                if (bodyIsJson && JsonStringValue(body, name, value)) return true;
                if (bodyIsJson && JsonUnsignedText(body, name, value)) return true;
                return false;
            };

            std::string titleIdText;
            std::string locale;
            std::string version;
            std::string platform;
            std::string logExtras;
            std::string serviceLevel;
            std::string ivSeed;
            std::string machineId;
            std::string platformToken;
            const bool titleOk = readField("titleID", titleIdText);
            readField("locale", locale);
            readField("version", version);
            const bool platformOk = readField("platform", platform);
            readField("logExtras", logExtras);
            const bool serviceLevelOk = readField("serviceLevel", serviceLevel);
            const bool ivOk = readField("ivSeed", ivSeed);
            const bool machineOk = readField("machineID", machineId);
            const bool tokenOk = readField("token", platformToken);

            std::uint32_t titleId = 0;
            if (titleOk)
            {
                char* end = nullptr;
                const unsigned long parsed = std::strtoul(titleIdText.c_str(), &end, 10);
                if (end && end != titleIdText.c_str() && *end == '\0')
                    titleId = static_cast<std::uint32_t>(parsed & 0xFFFFFFFFu);
            }

            const bool requestShapeOk = titleId != 0 && ivOk && machineOk && tokenOk;
            std::ostringstream detail;
            detail << "Steam loginservice local bridge"
                   << " title=" << (titleId ? std::to_string(titleId) : "?")
                   << " platform=" << (platformOk ? platform : "?")
                   << " serviceLevel=" << (serviceLevelOk ? serviceLevel : "?")
                   << " versionLen=" << version.size()
                   << " locale=" << (locale.empty() ? "?" : locale)
                   << " logExtras=" << (logExtras.empty() ? "?" : logExtras)
                   << " ivSeed=" << (ivOk ? "present" : "missing")
                   << " machineIdLen=" << machineId.size()
                   << " platformTokenLen=" << platformToken.size()
                   << " tokenForwarded=no"
                   << " responseSchema=STEAM_LOGIN_COMPAT_SUPERSET";

            result.handled = true;
            result.label = detail.str();
            if (!requestShapeOk)
            {
                result.statusCode = 400;
                result.response = BuildResponse(400, "Bad Request", "application/json; charset=utf-8",
                    "{\"error\":\"revamped_bad_steam_login_shape\"}");
                log::Print("[STEAM-LOGIN] reject host=%s title=%s iv=%s machineIdLen=%llu tokenLen=%llu keys=%s",
                    result.host.c_str(), titleId ? std::to_string(titleId).c_str() : "?",
                    ivOk ? "present" : "missing",
                    static_cast<unsigned long long>(machineId.size()),
                    static_cast<unsigned long long>(platformToken.size()), result.formKeys.c_str());
            }
            else
            {
                if (serviceLevel.empty()) serviceLevel = "paid";
                if (platform.empty()) platform = "steam";

                // Reuse the proven local ticket/session generator.  The synthetic
                // request task value is only an internal compatibility seed; the
                // Steam response below also publishes the modern camelCase fields.
                std::string responseBody = BuildDwBnetAuthResponse(
                    "84", ivSeed, titleId, machineId, serviceLevel,
                    "revamped", std::string{}, machineId);

                ReplaceJsonStringValue(responseBody, "client_id", "iw-cod-iw8-steam");
                ReplaceJsonStringValue(responseBody, "account_type", "steam");
                const std::string crossplayFalse = "\"crossplay_enabled\":false";
                const std::size_t crossplayPos = responseBody.find(crossplayFalse);
                if (crossplayPos != std::string::npos)
                    responseBody.replace(crossplayPos, crossplayFalse.size(), "\"crossplay_enabled\":true");

                std::string clientTicket;
                std::string serverTicket;
                JsonStringValue(responseBody, "client_ticket", clientTicket);
                JsonStringValue(responseBody, "server_ticket", serverTicket);

                const std::uint64_t localUserId = StableLocalAuthUserId(machineId, titleId);
                const std::string clientId = "iw-cod-iw8-steam";
                const std::string localLsg = "mw-lobby-1.prod.demonware.net";
                // Exact Steam retail capture: 0x6CACC30 requires these fields
                // inside `title`, not just at the response root. The 0x21-byte
                // string buffer decodes to the existing 24-byte local LSG key.
                const bool nativeRetailTitle = DetectLocalIw8Build() == LocalIw8Build::SteamRetail22824864;
                std::string nativeTitleFields;
                std::string nativeUmbrellaFields;
                std::string nativeUnoFields;
                const auto loginTicketIssueTime = static_cast<std::uint32_t>(std::time(nullptr));
                if (nativeRetailTitle)
                {
                    const std::string sessionKey = Base64Encode(std::vector<std::uint8_t>(
                        kLocalAuth3SessionKey, kLocalAuth3SessionKey + sizeof(kLocalAuth3SessionKey)));
                    nativeTitleFields = ",\"sessionID\":" + std::to_string(localUserId) +
                        ",\"crossplayEnabled\":true,\"sessionKey\":\"" + JsonEscape(sessionKey) +
                        "\",\"loginTicket\":\"" + JsonEscape(serverTicket) +
                        "\",\"loginTicketIssueTime\":" + std::to_string(loginTicketIssueTime);
                    // Captured 0x6CAC5C0: all five fields below are mandatory.
                    nativeUmbrellaFields = ",\"unoID\":" + std::to_string(localUserId) +
                        ",\"unoUsername\":\"revamped\",\"accessExpiresIn\":30000,\"refreshExpiresIn\":30000,"
                        "\"refreshToken\":\"" + JsonEscape(serverTicket) + "\"";
                    // Captured 0x6CAD0F0 uses userName (capital N), not username.
                    nativeUnoFields = ",\"unoID\":" + std::to_string(localUserId) +
                        ",\"userName\":\"revamped\"";
                }

                // Compatibility superset: old Auth3 snake_case fields remain in
                // place for shared login code, while current Steam loginservice
                // consumers can use camelCase and the title/umbrella/uno objects.
                if (!responseBody.empty() && responseBody.back() == '}')
                    responseBody.pop_back();
                std::ostringstream extra;
                extra << ",\"success\":true"
                      << ",\"titleID\":" << titleId
                      << ",\"clientID\":\"" << JsonEscape(clientId) << "\""
                      << ",\"userID\":" << localUserId
                      << ",\"accountType\":\"steam\""
                      << ",\"username\":\"revamped\""
                      << ",\"ivSeed\":\"" << JsonEscape(ivSeed) << "\""
                      << ",\"clientTicket\":\"" << JsonEscape(clientTicket) << "\""
                      << ",\"serverTicket\":\"" << JsonEscape(serverTicket) << "\""
                      << ",\"serviceLevel\":\"paid\""
                      << ",\"crossplayEnabled\":true"
                      << ",\"loginqueueEnabled\":false"
                      << ",\"lsgEndpoint\":\"" << JsonEscape(localLsg) << "\""
                      << ",\"ticket\":\"" << JsonEscape(clientTicket) << "\""
                      << ",\"token\":\"" << JsonEscape(clientTicket) << "\""
                      << ",\"title\":{\"titleID\":" << titleId
                      << ",\"clientID\":\"" << JsonEscape(clientId) << "\""
                      << ",\"userID\":" << localUserId
                      << ",\"accountType\":\"steam\""
                      << ",\"username\":\"revamped\""
                      << ",\"serviceLevel\":\"paid\""
                      << ",\"ivSeed\":\"" << JsonEscape(ivSeed) << "\""
                      << ",\"clientTicket\":\"" << JsonEscape(clientTicket) << "\""
                      << ",\"serverTicket\":\"" << JsonEscape(serverTicket) << "\""
                      << nativeTitleFields
                      << ",\"lsgEndpoint\":\"" << JsonEscape(localLsg) << "\"}"
                      << ",\"umbrella\":{\"umbrellaID\":" << localUserId
                      << nativeUmbrellaFields
                      << ",\"userID\":" << localUserId
                      << ",\"accountType\":\"steam\""
                      << ",\"username\":\"revamped\""
                      << ",\"accessToken\":\"" << JsonEscape(clientTicket) << "\""
                      << ",\"accounts\":[]"
                      << ",\"crossPlatformProgressionEnabled\":true"
                      << ",\"lsgEndpoint\":\"" << JsonEscape(localLsg) << "\"}"
                      << ",\"uno\":{\"userID\":" << localUserId
                      << nativeUnoFields
                      << ",\"accountType\":\"steam\""
                      << ",\"username\":\"revamped\"}"
                      << "}";
                // 0x6CBBEC1 rejects a zero issued-at value after all three
                // account objects pass. The title parser reads this as uint32.
                responseBody += extra.str();
                if (nativeRetailTitle)
                    log::Print("[STEAM-LOGIN-V4] exactBuild=22824864 nativeTitle=yes nativeUmbrella=yes nativeUno=yes issuedAt=present keyBytes=24 tokenForwarded=no stateWrites=off");

                result.statusCode = 200;
                // Sign the body too.  Clients that do not require X-Signature
                // simply ignore the extra header; clients sharing Auth3 trust code
                // can validate it with the already-installed local verifier.
                result.response = BuildDwAuthResponse(responseBody);

                AppendAuthPipelineV58(
                    "STEAM_LOGIN_RESPONSE status=200 host=%s titleId=%u platform=%s userId=%llu clientId=%s serviceLevel=paid ivSeedLen=%llu machineIdLen=%llu platformTokenLen=%llu tokenForwarded=no clientTicketLen=%llu serverTicketLen=%llu lsgEndpoint=%s schema=STEAM_LOGIN_COMPAT_SUPERSET",
                    result.host.c_str(), static_cast<unsigned>(titleId), platform.c_str(),
                    static_cast<unsigned long long>(localUserId), clientId.c_str(),
                    static_cast<unsigned long long>(ivSeed.size()),
                    static_cast<unsigned long long>(machineId.size()),
                    static_cast<unsigned long long>(platformToken.size()),
                    static_cast<unsigned long long>(clientTicket.size()),
                    static_cast<unsigned long long>(serverTicket.size()), localLsg.c_str());
                log::Print(
                    "[STEAM-LOGIN] status=200 host=%s titleId=%u platform=%s userId=%llu ticketLens=%llu/%llu tokenForwarded=no schema=STEAM_LOGIN_COMPAT_SUPERSET next=observe_client",
                    result.host.c_str(), static_cast<unsigned>(titleId), platform.c_str(),
                    static_cast<unsigned long long>(localUserId),
                    static_cast<unsigned long long>(clientTicket.size()),
                    static_cast<unsigned long long>(serverTicket.size()));
            }
        }
        else if (result.method == "POST" && pathLower == "/auth/" &&
            hostLower.find("demonware.net") != std::string::npos)
        {
            std::string authTask;
            std::string titleIdText;
            std::string ivSeed;
            std::string identity;
            std::string serviceLevel;
            std::string extraData;
            const std::string transactionId = HeaderValue(headers, "X-TransactionID");
            const std::string requestSignature = HeaderValue(headers, "X-Signature");
            const std::string acceptType = HeaderValue(headers, "Accept");
            const std::string userAgent = HeaderValue(headers, "User-Agent");
            const bool taskOk = bodyIsJson && JsonUnsignedText(body, "auth_task", authTask);
            const bool titleOk = bodyIsJson && JsonUnsignedText(body, "title_id", titleIdText);
            const bool ivOk = bodyIsJson && JsonUnsignedText(body, "iv_seed", ivSeed);
            const bool identityOk = bodyIsJson && JsonStringValue(body, "identity", identity);
            const bool serviceLevelOk = bodyIsJson && JsonStringValue(body, "service_level", serviceLevel);
            const bool extraDataOk = bodyIsJson && JsonStringValue(body, "extra_data", extraData) && LooksLikeJsonObject(extraData);

            std::string sessionToken;
            std::string accountToken;
            std::string machineId;
            std::string version;
            if (extraDataOk)
            {
                JsonStringValue(extraData, "session_token", sessionToken);
                JsonStringValue(extraData, "account_token", accountToken);
                JsonStringValue(extraData, "machine_id", machineId);
                JsonStringValue(extraData, "version", version);
            }

            const bool sessionTokenPrintableAscii = !sessionToken.empty() &&
                std::all_of(sessionToken.begin(), sessionToken.end(), [](const unsigned char c) {
                    return c >= 0x20u && c <= 0x7Eu;
                });
            const std::size_t sessionTokenControlBytes = static_cast<std::size_t>(
                std::count_if(sessionToken.begin(), sessionToken.end(), [](const unsigned char c) {
                    return c < 0x20u || c == 0x7Fu;
                }));

            std::uint32_t titleId = 0;
            if (titleOk)
            {
                const unsigned long parsed = std::strtoul(titleIdText.c_str(), nullptr, 10);
                titleId = static_cast<std::uint32_t>(parsed & 0xFFFFFFFFu);
            }

            std::ostringstream detail;
            detail << "IW8 Demonware BNet auth json=" << (bodyIsJson ? "yes" : "no")
                   << " task=" << (taskOk ? authTask : "?")
                   << " responseTask=" << (taskOk ? std::to_string(std::strtoul(authTask.c_str(), nullptr, 10) + 1u) : "?")
                   << " title=" << (titleOk ? titleIdText : "?")
                   << " ivSeed=" << (ivOk ? "present" : "missing")
                   << " identityLen=" << (identityOk ? identity.size() : 0u)
                   << " serviceLevel=" << (serviceLevelOk ? serviceLevel : "?")
                   << " extraDataJson=" << (extraDataOk ? "yes" : "no")
                   << " nestedKeys=" << (extraDataOk ? JsonTopLevelKeys(extraData) : "")
                   << " versionLen=" << version.size()
                   << " sessionTokenLen=" << sessionToken.size()
                   << " sessionTokenPrintableAscii=" << (sessionTokenPrintableAscii ? "yes" : "no")
                   << " sessionTokenControlBytes=" << sessionTokenControlBytes
                   << " accountTokenLen=" << accountToken.size()
                   << " machineIdLen=" << machineId.size()
                   << " transactionId=" << (transactionId.empty() ? "missing" : "present")
                   << " transactionIdLen=" << transactionId.size()
                   << " requestSignature=" << (requestSignature.empty() ? "missing" : "present")
                   << " requestSignatureLen=" << requestSignature.size()
                   << " accept=" << (acceptType.empty() ? "missing" : acceptType)
                   << " userAgentLen=" << userAgent.size()
                   << " ticketMode=BNET_RAW_128 responseStyle=TASK_PLUS_ONE clientIdOut=iw-cod-iw8-bnet serviceLevelOut=paid"
                   << " responsePlatformData=session+account+machine"
                   << " responseSignature=RSA_PSS_SHA256"
                   << " httpStyle=TornadoServer/4.5.3 stateWrites=off";

            if (!bodyIsJson || !taskOk || !titleOk || !ivOk || !extraDataOk || sessionToken.empty())
            {
                result.handled = true;
                result.statusCode = 400;
                result.label = detail.str();
                AppendAuthPipelineV58("AUTH3_REJECT task=%s title=%s iv=%s extraData=%s sessionTokenLen=%llu",
                    taskOk ? authTask.c_str() : "?", titleOk ? titleIdText.c_str() : "?", ivOk ? "present" : "missing",
                    extraDataOk ? "yes" : "no", static_cast<unsigned long long>(sessionToken.size()));
                result.response = BuildResponse(400, "Bad Request", "application/json; charset=utf-8",
                    "{\"auth_task\":\"85\",\"code\":\"701\",\"error\":\"revamped_bad_dw_bnet_auth_shape\"}");
            }
            else
            {
                result.handled = true;
                result.statusCode = 200;
                result.label = detail.str();
                result.response = BuildDwAuthResponse(
                    BuildDwBnetAuthResponse(authTask, ivSeed, titleId, identity, serviceLevel,
                        sessionToken, accountToken, machineId));
                const LocalIw8Build localBuild = DetectLocalIw8Build();
                const bool legacyUmbrellaHandoff = UsesLegacyUmbrellaHandoff(localBuild);
                const bool crossplayEnabled = legacyUmbrellaHandoff || LsgForceTestEnabled();
                const auto& localBuildProbe = LocalIw8BuildProbeState();
                AppendAuthPipelineV58("AUTH3_RESPONSE status=200 requestTask=%s responseTask=%lu titleId=%u clientId=iw-cod-iw8-bnet accountType=bnet serviceLevel=paid localBuild=%s buildSource=%s buildFingerprint=%08X/%08X/%08X crossplay_enabled=%s loginqueue_enabled=false lsg_endpoint=%s lsg_port=3074 handoff=%s forceLsgTest=%s signed=RSA_PSS_SHA256",
                    authTask.c_str(), std::strtoul(authTask.c_str(), nullptr, 10) + 1u, static_cast<unsigned>(titleId),
                    LocalIw8BuildName(localBuild),
                    LocalIw8BuildSource(),
                    static_cast<unsigned>(localBuildProbe.timestamp),
                    static_cast<unsigned>(localBuildProbe.imageSize),
                    static_cast<unsigned>(localBuildProbe.entryPoint),
                    crossplayEnabled ? "true" : "false",
                    legacyUmbrellaHandoff ? "null" : "mw-lobby-1.prod.demonware.net",
                    legacyUmbrellaHandoff ? "AUTH3_THEN_UMBRELLA_CROSSPLATFORM" : "AUTH3_DIRECT_LSG_HOST",
                    LsgForceTestEnabled() ? "ENABLED" : "disabled");
            }
        }
        else if (pathLower == "/optinservice/v1/getaccountoptins")
        {
            // Empty local consent collection: structurally valid and intentionally
            // contains no synthetic marketing/account-consent choices.
            result.handled = true;
            result.statusCode = 200;
            result.label = "local empty account opt-ins";
            result.response = BuildResponse(200, "OK", "application/json; charset=utf-8", "{\"optInSelections\":[]}");
        }
        else
        {
            result.handled = false;
            result.statusCode = 404;
            result.label = "unimplemented local HTTPS endpoint";
            result.response = BuildResponse(404, "Not Found", "application/json; charset=utf-8", "{\"error\":\"revamped_unimplemented\"}");
        }

        buffer.erase(buffer.begin(), buffer.begin() + static_cast<std::ptrdiff_t>(totalBytes));
        return result;
    }
}
