#pragma once

// Module boundary for Tls/Transport/TlsEngine.
// Its implementation is compiled through ServerTls.cpp so legacy private helper
// linkage/state remains unchanged while the source is physically separated.
