#pragma once

// Module boundary for Demonware/Services/PublisherVariables.
// Its implementation is compiled through Demonware/DemonwareTaskRouter.cpp so legacy private helper
// linkage/state remains unchanged while the source is physically separated.
