namespace codrevamped_project_anchor { void common() {} }
